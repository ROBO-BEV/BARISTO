  GNU nano 2.5.3            File: index.ts                            
/**
 * @file     index.ts
 * @author   Blaze Sanders (@ROBO_BEV)
 * @email    blaze@robobev.com
 * @updated  1 April 2018
 *
 * @version 0.1
 * @brief Main driver program for the Baristo coffee kiosk
 *
 * @link https://www.robobev.com
 *
 * @section DESCRIPTION
 *
 * Yes we are programming a coffee robot in JAVA..script
 *
 */


//Sensor hardware constants
NUM_OF_CAMS = 5
AUSDOM_CAM_PART_NUMBER = AW_335
//TO-DO: ON_SEMI_PART_NUMBER = 999

NUM_OF_ULTRASONICS = 3
PARALLAX_ULTRASONIC_PART_NUMBER = 28015

NUM_OF_RFID_TRANSCEIVERS = 1
PARALLAX_RFID_TXRX_PART_NUMBER = 28140

//Actuator hardware constants
FIRGELLI_LINEAR_ACTUATOR_PART_NUMBER = FA_B_20_12V
AMAZON_ECHO_NAME = DOT_2
SEEDSTUDIO_RESPEAKER_PART_NUMBER = 103030216 
ADAFRUIT_WATER_VALVE_PART_NUMBER = 997

import * as Typings from "@4th-law/typings"

export default class ModalityTemplate extends Typings.Modality {
  protected _baseType: string
  protected _make: string
  protected _model: string
  protected _id: string
  protected _version: string
  protected _platformID: string
  protected _state: NModalities.IState
  protected _error: NModalities.IError
  protected _userCommand: NModalities.IControlCommand

  constructor() {
    super()
    this._baseType = "VENDING_MACHINE"
    this._make = "Robotic Beverage Technologies"
    this._model = "BARISTO"
    this._id = "MVP"
    this._version = "v0.1.0"
    this._platformID = "0"
    this._state = {timestamp: 0, vector: [0], } as NModalities.IState
    this._error = {timestamp: 0, vector: [0], } as NModalities.IError
    this._userCommand = {timestamp: 0, userCommand: [0], } as NModalities.IControlCommand
  }
  
  public configureBARISTO(bootMode, verNum){
    ParallaxHardware kioskRFID = new ParallaxHardware
    ParallaxHardware kioskUltrasonicSensors = new ParallaxHardware

    //Critical Subsystems
    errorCodes[errorNum++] = ?IntializeBatteries(bootMode, verNum);
    errorCodes[errorNum++] = ?IntializeSolarPanels(bootMode, verNum$
    errorCodes[errorNum++] = ?.IntializeRFID(bootMode, verNum, Para$

    //Coffee Subsystems
    //Check feedstock levels (e.g water, coffee bean), test linear actuator$
    ?.IntializeFeedstock(bootMode, verNum);
    ?.IntializeHeaters(bootMode, verNum);
    ?.IntializeValves(bootMode, verNum);
    ?.IntializePumps(bootMode, verNum);
    ?.IntializeLinearActuators(bootMode, verNum);  
  
    //Sensor Subsystems
    //Test and turn on cameras, distance sensors, audio input & output hardware devices
    //Load QR code software and cache some user profiles for possible offline vending
    //TO-DO: OnSemiConductorHardware.IntializeCameras(bootMode, verNum, num$
    //TO-DO: InitializeQRCodeScanner(bootmode, verNum) //TO-DO CONNECT TO A$

    ?.IntializeUltrasonicSensors(bootMode, verNum)

  }
  
  public translate(controlCommand: NModalities.IControlCommand): NModalities.IActuatorCommand[] {
    int xDistance = {timestamp: 0, routerID: "0", actuator: [0], } PING
    const returnValue = [xDistance] as NModalities.IActuatorCommand[ TODO ]

    int yDistance = {timestamp: 0, routerID: "0", actuator: [0], } PING
    int zDistance = {timestamp: 0, routerID: "0", actuator: [0], } PING
    
    const value = {timestamp: 0, routerID: "0", actuatorInput: [0], }
    const returnValue = [value] as NModalities.IActuatorCommand[]
    return returnValue
  }
}
