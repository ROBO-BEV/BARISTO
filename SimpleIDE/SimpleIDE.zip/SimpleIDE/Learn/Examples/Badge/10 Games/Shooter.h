
#ifndef SHOOTER_H__
#define SHOOTER_H__

typedef struct
{
  signed char dist, ang;
} SHOT;

#endif
